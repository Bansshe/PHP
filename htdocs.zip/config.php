<?php

return [

    'Versao' => 'Pre-Release 1.0.0',
    'Servidor' => 'localhost',
    
];